#ifndef ENEMY_H
#define ENEMY_H

#include "waypoint.h"
#include "mainwindow.h"
#include "tower.h"

#include <QObject>
#include <QPoint>
#include <QPainter>
#include <QSize>
#include <QPixmap>
#include <QDebug>
#include <QColor>
#include <QVector2D>
#include <QtMath>
#include <QList>

class Tower;
class MainWindow;
class WayPoint;
class Enemy :public QObject
{
    Q_OBJECT
public:
    Enemy(WayPoint *startWayPoint,MainWindow *game, const QPixmap &sprite=QPixmap(":/image/enemy.png"));
    ~Enemy();


    void draw(QPainter *painter) const; //绘制
    void move();  //敌人移动
    bool judge(QPoint point1,QPoint point2); //判断敌人是否到达了下一个路线点
    void attacked(Tower *attacker); // 受到攻击，将攻击的这个塔存入列表
    void lostSight(Tower *attacker);//跑出攻击范围，将列表的塔移除
    void Damage(int damage); //受到攻击自身血量减少，并判断是否身亡进行remover()操作
    void remove();//将攻击对象从塔的列表中清除，通知game进行移除

public slots:
    void doActivate();


public:
    bool             _active=false;//敌人状态，是否产生
    QPoint           _nowpos; //当前路线点的坐标
    WayPoint *       _nextpoint; //移动的下一个路线点的坐标
    MainWindow *     _game;
    QList<Tower *>   _attackingTowerList;
    const QPixmap    _sprite; //敌人图片
    static const QSize      _fixedSize; //图片大小
    qreal            _rotation=0.0;  //图片偏转的度数
    qreal            _speed=1.0; //敌人移动的速度
    int              _currentHp=40;//当前血量值
    int              _maxHp=40;//最大血量值


};

#endif // ENEMY_H
