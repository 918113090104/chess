#ifndef BULLET_H
#define BULLET_H

#include "enemy.h"
#include "mainwindow.h"

#include <QObject>
#include <QPoint>
#include <QPainter>
#include <QSize>
#include <QPixmap>
class MainWindow;
class Enemy;
class Bullet : QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint _currentPos READ currentPos WRITE setCurrentPos)

public:
    Bullet(QPoint startPos, QPoint targetPoint, int damage, Enemy *target,
           MainWindow *game, const QPixmap &sprite = QPixmap(":/image/bullet.png"));

    void draw(QPainter *painter) const;  //绘制子弹
    void move(); //子弹的移动
    void setCurrentPos(QPoint pos); //设置当前子弹位置
    QPoint currentPos() const; //返回子弹当前位置

private slots:
    void hitTarget();

private:
    const QPoint   _startPos;   //子弹初始位置
    const QPoint   _targetPos; // 子弹目标位置
    const QPixmap  _sprite;  //放子弹图片
    static const QSize    _fixedSize;//图片大小
    QPoint         _currentPos;  //子弹当前位置
    Enemy *        _target; //目标敌人
    MainWindow *   _game; //
    int            _damage; //子弹伤害值
};

#endif // BULLET_H
