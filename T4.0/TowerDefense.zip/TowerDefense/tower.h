 #ifndef TOWER_H
#define TOWER_H
#include "mainwindow.h"
#include "enemy.h"

#include <QObject>
#include <QPixmap>
#include <QSize>
#include <QObject>
#include <QPainter>
#include <QColor>
#include <QTimer>
#include <QVector2D>
#include <QtMath>
class MainWindow;
class Enemy;
class Tower : QObject
{
    Q_OBJECT    //用到槽函数的类必须有Q_OBJECT
public:
    Tower(QPoint pos,MainWindow *game, const QPixmap &sprite=QPixmap(":/image/t.png"));
    ~Tower();
    void draw(QPainter *painter) const;
    void checkEnemyInRange();
    bool judgeArrage(QPoint point1,QPoint point2);
    void chooseForattack(Enemy *enemy);
    void targetkilled();
    void outsight();
private slots:
    void shootWeapon();

private:
    QPoint       _pos;  //点击的位置对应基地的左上角左边
    QPixmap      _sprite;//塔的图片
    QSize        _fixedSize=QSize(70,70);//塔的大小
    MainWindow *  _game;
    Enemy *       _chooseEnemy=NULL;
    qreal         _rotation;//炮台偏转的度数
    int           _attackRange=112;//攻击范围
    int			  _damage;// 攻击敌人造成的伤害
    QTimer *      _attackTimer;

};

#endif // TOWER_H
