#include "bullet.h"
#include <QPropertyAnimation>
Bullet::Bullet(QPoint startPos, QPoint targetPoint, int damage, Enemy *target,
               MainWindow *game, const QPixmap &sprite)
    :_startPos(startPos),_targetPos(targetPoint),_sprite(sprite),_currentPos(startPos),
      _target(target),_game(game),_damage(damage)

{

}
const QSize Bullet::_fixedSize(13, 13);//大小设置


void Bullet::draw(QPainter *painter) const
{
    painter->drawPixmap(_currentPos,_sprite);
}

void Bullet::move()
{
    // 100毫秒内击中敌人
    static const int duration = 100;
    //子弹攻击动画效果
    QPropertyAnimation *animation = new QPropertyAnimation(this, "_currentPos");
    animation->setDuration(duration);
    animation->setStartValue(_startPos);
    animation->setEndValue(_targetPos);
    connect(animation, SIGNAL(finished()), this, SLOT(hitTarget()));

    animation->start();
}

void Bullet::setCurrentPos(QPoint pos)
{
    _currentPos=pos;
}

QPoint Bullet::currentPos() const
{
    return _currentPos;
}

void Bullet::hitTarget()
{
    // 防止其中一个将其消灭,导致敌人delete
    // 后续炮弹再攻击到的敌人就是无效内存区域
    // 判断下敌人是否还有效
    if (_game->_enemyList.indexOf(_target) != -1)
        _target->Damage(_damage);
    _game->removeBullet(this);
}
