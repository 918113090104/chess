#include "tower.h"

Tower::Tower(QPoint pos,MainWindow *game ,const QPixmap &sprite)
    :_pos(pos),_sprite(sprite),_game(game)

{
    _attackTimer=new QTimer(this);
    connect(_attackTimer,SIGNAL(timeout()),this,SLOT(shootWeapon()));
}
Tower::~Tower()
{
    delete _attackTimer;
    _attackTimer=NULL;

}

void Tower::draw(QPainter *painter) const
{
    painter->save();
    //绘制攻击范围
    painter->setPen(Qt::green);
    painter->drawEllipse(_pos,_attackRange,_attackRange);

    // 绘制炮塔并选择炮塔
    static const QPoint offsetPoint(-_fixedSize.width() / 2,- _fixedSize.height() / 2);
    painter->translate(_pos);
    painter->rotate(_rotation);
    painter->drawPixmap(offsetPoint,_sprite);

    painter->restore();
}

void Tower::checkEnemyInRange()
{
    if(_chooseEnemy){
        // 这种情况下,需要旋转炮台对准敌人
        // 向量标准化
        QVector2D normalized(_chooseEnemy->_nowpos - _pos); //向量，炮台指向敌人
        normalized.normalize();
        //arctan反三角函数求度数
        _rotation=qRadiansToDegrees(qAtan2(normalized.y(),normalized.x()));

        // 如果敌人脱离攻击范围
        if(!judgeArrage(_pos,_chooseEnemy->_nowpos)){
            outsight();
        }
        else{
            // 遍历敌人,看是否有敌人在攻击范围内
            QList<Enemy *> enemyList0 = _game->_enemyList;
            foreach (Enemy *enemy, enemyList0)
            {
                if (judgeArrage(_pos,enemy->_nowpos))
                {

                    chooseForattack(enemy);
                    break;
                }

            }

          }

     }
}

//判断敌人是否在塔的攻击范围内
bool Tower::judgeArrage(QPoint point1, QPoint point2)
{
    int dx=point1.x()-point2.x();
    int dy=point1.y()-point2.y();
    int distance=qSqrt(dx*dx+dy*dy);
    if(distance<_attackRange)
        return true;
    return false;
}

void Tower::chooseForattack(Enemy *enemy)
{
    _chooseEnemy=enemy;//enemy作为选择攻击的对象
    _attackTimer->start(1000); //定时器间隔1s，攻击间隔为1s
    _chooseEnemy->attacked(this); //调用敌人的attacke()函数,将发出攻击的这个塔存起来
}


void Tower::shootWeapon()
{
    Bullet *bullet = new Bullet(_pos, _chooseEnemy->_nowpos, _damage, _chooseEnemy, _game);
    bullet->move();
    _game->addBullet(bullet);
}
void Tower::targetkilled()
{
    //目标被杀死，则选择的目标改为NULL，发射子弹的定时器stop，偏转角度恢复0
    if(_chooseEnemy)
        _chooseEnemy=NULL;
    _attackTimer->stop();
    _rotation=0.0;
}

void Tower::outsight()
{
    //敌人跑出视线，调用敌人的lostsight()函数，将敌人存储攻击的塔的列表中移除这个塔
    _chooseEnemy->lostSight(this);
    if(_chooseEnemy)
        _chooseEnemy=NULL;
    _attackTimer->stop();
    _rotation=0.0;
}

