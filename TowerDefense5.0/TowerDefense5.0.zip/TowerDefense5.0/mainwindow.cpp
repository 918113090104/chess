#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "waypoint.h"
#include "enemy.h"
#include "bullet.h"
#include "plistreader.h"
#include <QPainter>
#include <QMouseEvent>
#include <QtGlobal>
#include <QMessageBox>
#include <QTimer>
#include <QXmlStreamReader>
#include <QtDebug>

static const int TowerCost = 300;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    ,  main_waves(0)
    ,  main_playerHp(5)
    ,  main_playrGold(1000)
    ,  main_gameEnded(false)
    ,  main_gameWin(false)
{
    ui->setupUi(this);

     main_preLoadWavesInfo();
     main_loadTowerPositions();
     main_addWayPoints();


    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateMap()));
    timer->start(30);

    // 设置300ms后游戏启动
    QTimer::singleShot(300, this, SLOT(gameStart()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

//获得基地的位置(从.plist文件里获取),并存入towerPositionsList
void MainWindow:: main_loadTowerPositions()
{
    QFile file(":/config/TowersPosition.plist");//打开文件，读取失败则返回失败信息
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this, "TowerDefense", "Cannot Open TowersPosition.plist");
        return;
    }

    PListReader reader;
     reader. P_read(&file);//读取文件

    QList<QVariant> array = reader.data();//array存放文件中读取的数据
    foreach (QVariant dict, array)//在array中遍历搜索
    {
        QMap<QString, QVariant> point = dict.toMap();
        int x = point.value("x").toInt();
        int y = point.value("y").toInt();
         main_towerPositionsList.push_back(QPoint(x, y));
    }

    file.close();
}

void MainWindow::paintEvent(QPaintEvent *)
{
    if ( main_gameEnded ||  main_gameWin)
    {
        QString text =  main_gameEnded ? "很遗憾失败了，下次会更好!!!" : "恭喜你 胜利了!!!";
        QPainter painter(this);
        painter.setPen(QPen(Qt::red));
        painter.drawText(rect(), Qt::AlignCenter, text);
        return;
    }

    QPixmap cachePix(":/image/Bg.png");
    QPainter cachePainter(&cachePix);

    //从towerPositionsList中遍历基地的位置,绘制基地
    foreach (const TowerPosition &towerPos,  main_towerPositionsList)
        towerPos.draw(&cachePainter);

    //从towersList中遍历塔的位置,绘制塔
    foreach (const Tower *tower,  main_towersList)
        tower-> t_draw(&cachePainter);

    //从wayPointsList中遍历路线点,绘制路线
    foreach (const WayPoint *wayPoint, main_wayPointsList)
        wayPoint->draw(&cachePainter);

    //从enemyList中遍历路线点,绘制路线
    foreach (const Enemy *enemy,  main_enemyList)
        enemy->d(&cachePainter);

     //从bulletList中遍历路线点,绘制路线
    foreach (const Bullet *bullet,  main_bulletList)
        bullet->draw(&cachePainter);

     main_drawWave(&cachePainter);
     main_drawHP(&cachePainter);
     main_drawPlayerGold(&cachePainter);

    QPainter painter(this);
    painter.drawPixmap(0, 0, cachePix);
}

//点击放塔操作
void MainWindow::mousePressEvent(QMouseEvent *event)
{
    QPoint pressPos = event->pos();//获取点击的位置
    auto it =  main_towerPositionsList.begin();
    while (it !=  main_towerPositionsList.end())
    {
        // 钱够买塔&&点击的位置在范围之内&&该位置是否已经有塔
        if ( main_canBuyTower() && it->containPoint(pressPos) && !it->Tower())
        {

             main_playrGold -= TowerCost;
            it->HOST();
            //放塔
            Tower *tower = new Tower(it->centerPos(), this);
             main_towersList.push_back(tower);
            update();
            break;
        }

        ++it;
    }
}
//金币是否够买塔
bool MainWindow:: main_canBuyTower() const
{
     //玩家金币数量够买塔则返回true
    if ( main_playrGold >= TowerCost)
        return true;
    return false;
}

void MainWindow:: main_drawWave(QPainter *painter)
{
    painter->setPen(QPen(Qt::yellow));
    painter->drawText(QRect(640, 8, 160, 40), QString("WAVE : %1").arg( main_waves + 1));
}
//***************************************************
void MainWindow:: main_drawHP(QPainter *painter)
{
    painter->setPen(QPen(Qt::yellow));
    painter->drawText(QRect(48, 8, 160, 40), QString("HP : %1").arg( main_playerHp));
}

void MainWindow:: main_drawPlayerGold(QPainter *painter)
{
    painter->setPen(QPen(Qt::yellow));
    painter->drawText(QRect(320, 8, 320, 40), QString("GOLD : %1").arg( main_playrGold));
}

void MainWindow:: main_doGameOver()
{
    if (! main_gameEnded)
    {
         main_gameEnded = true;

    }
}

//玩家获得金币
void MainWindow::awardGold(int gold)
{
     main_playrGold += gold;
    update();
}

AudioPlayer *MainWindow::audioPlayer() const
{
    return  main_audioPlayer;
}
//设置路线点
void MainWindow:: main_addWayPoints()
{
    WayPoint *wayPoint1 = new WayPoint(QPoint(690, 473));
     main_wayPointsList.push_back(wayPoint1);

    WayPoint *wayPoint2 = new WayPoint(QPoint(58, 473));
     main_wayPointsList.push_back(wayPoint2);
    wayPoint2->setNextWayPoint(wayPoint1);

    WayPoint *wayPoint3 = new WayPoint(QPoint(58, 323));
     main_wayPointsList.push_back(wayPoint3);
    wayPoint3->setNextWayPoint(wayPoint2);

    WayPoint *wayPoint4 = new WayPoint(QPoint(739,323));
     main_wayPointsList.push_back(wayPoint4);
    wayPoint4->setNextWayPoint(wayPoint3);

    WayPoint *wayPoint5 = new WayPoint(QPoint(425,167));
     main_wayPointsList.push_back(wayPoint5);
    wayPoint5->setNextWayPoint(wayPoint4);

    WayPoint *wayPoint6 = new WayPoint(QPoint(68,167));
     main_wayPointsList.push_back(wayPoint6);
    wayPoint6->setNextWayPoint(wayPoint5);
}

void MainWindow::getHpDamage(int damage)
{

     main_playerHp -= damage;
    if ( main_playerHp <= 0)
         main_doGameOver();
}
//敌人被消灭，进行清除操作
void MainWindow::removedEnemy(Enemy *enemy)
{
    Q_ASSERT(enemy);

     main_enemyList.removeOne(enemy);
    delete enemy;

    if ( main_enemyList.empty())
    {
        ++ main_waves;
        if (! main_loadWave())
        {
             main_gameWin = true;


        }
    }
}
//清除子弹
void MainWindow::removedBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);

     main_bulletList.removeOne(bullet);
    delete bullet;
}

void MainWindow::addBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);

     main_bulletList.push_back(bullet);
}

//地图的更新，敌人移动和塔的转动攻击
void MainWindow::updateMap()
{
    foreach (Enemy *enemy,  main_enemyList)
        enemy->m();
    foreach (Tower *tower,  main_towersList)
        tower-> t_checkEnemyInRange();
    update();
}

//获得攻击波数的信息(从.plist文件里获取
void MainWindow:: main_preLoadWavesInfo()
{
    QFile file(":/config/Waves.plist");
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this, "TowerDefense", "Cannot Open Waves.plist");
        return;
    }

    PListReader reader;
    reader. P_read(&file);

    // 获取波数信息
     main_wavesInfo = reader.data();

    file.close();
}

//将获得的波数信息存入enemyList列表
bool MainWindow:: main_loadWave()
{
    if ( main_waves >=  main_wavesInfo.size())
        return false;

    WayPoint *startWayPoint =  main_wayPointsList.back();
    QList<QVariant> curWavesInfo =  main_wavesInfo[ main_waves].toList();

    for (int i = 0; i < curWavesInfo.size(); ++i)
    {
        QMap<QString, QVariant> dict = curWavesInfo[i].toMap();
        int spawnTime = dict.value("spawnTime").toInt();

        Enemy *enemy = new Enemy(startWayPoint, this);
         main_enemyList.push_back(enemy);
         //单次定时器
        QTimer::singleShot(spawnTime, enemy, SLOT(doActivate()));
    }

    return true;
}

QList<Enemy *> MainWindow::enemyList() const
{
    return  main_enemyList;
}

void MainWindow::gameStart()
{
     main_loadWave();
}
