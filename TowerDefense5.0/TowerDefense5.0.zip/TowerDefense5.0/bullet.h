#ifndef BULLET_H
#define BULLET_H
#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>


class QPainter;
class Enemy;
class MainWindow;

class Bullet : QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint m_currentPos READ currentPos WRITE setCurrentPos)

public:
    Bullet(QPoint startPos, QPoint targetPoint, int damage, Enemy *target,
           MainWindow *game, const QPixmap &sprite = QPixmap(":/image/bullet.png"));

    void draw(QPainter *painter) const;//绘制子弹
    void m();//子弹的移动
    void setCurrentPos(QPoint pos); //设置当前子弹位置
    QPoint currentPos() const; //返回子弹当前位置

private slots:
    void hitTarget();

private:
    const QPoint	m_startPos;//子弹初始位置
    const QPoint	m_targetPos; // 子弹目标位置
    const QPixmap	m_sprite;//放子弹图片
    QPoint			m_currentPos;//子弹当前位置
    Enemy *			m_target; //目标敌人
    MainWindow *	m_game;
    int				m_damage;//子弹伤害值

    static const QSize ms_fixedSize;//图片大小
};

#endif // BULLET_H
