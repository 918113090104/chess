#include "waypoint.h"
#include <QPainter>
#include <QColor>

WayPoint::WayPoint(QPoint pos)
	: m_pos(pos)
    , w_Point(NULL)
{
}

WayPoint* WayPoint::nextWayPoint() const
{
    return  w_Point;
}

const QPoint WayPoint::pos() const
{
    return m_pos;
}

void WayPoint::draw(QPainter *painter) const
{
	painter->save();
    painter->setPen(Qt::cyan);
    painter->drawEllipse(m_pos, 3, 3);
    painter->drawEllipse(m_pos, 9, 9);

    if ( w_Point)
        painter->drawLine(m_pos,  w_Point->m_pos);
	painter->restore();
}

void WayPoint::setNextWayPoint(WayPoint *nextPoint)
{
     w_Point = nextPoint;
}
