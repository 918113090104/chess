#include "enemy.h"
#include "waypoint.h"
#include "inline.h"
#include "tower.h"
#include <QPainter>
#include "mainwindow.h"
#include <QDebug>
#include <QMatrix>
#include <QColor>
#include <QVector2D>
#include <QtMath>



const QSize Enemy::ms_fixedSize(86, 86);

Enemy::Enemy(WayPoint *startWayPoint, MainWindow *game, const QPixmap &sprite)
    : QObject(0)
    , e_active(false)
    , e_maxHp(40)
    , e_currentHp(40)
    , e_walkingSpeed(1.0)
    , e_rotationSprite(0.0)
    , e_pos(startWayPoint->pos())
    ,e_Point(startWayPoint->nextWayPoint())
    , e_game(game)
    , e_sprite(sprite)
{
}

Enemy::~Enemy()
{
    e_attackedTowersList.clear();
    e_Point = NULL;
    e_game = NULL;
}

void Enemy::doActivate()
{
    e_active = true;
}

void Enemy::m()
{
    if (!e_active)
        return;

    if (collisionWithCircle(e_pos, 1, e_Point->pos(), 1))
    {
        // 敌人抵达了一个航点
        if (e_Point->nextWayPoint())
        {
            // 还有下一个航点
            e_pos = e_Point->pos();
            e_Point =e_Point->nextWayPoint();
        }
        else
        {
            // 表示进入基地
            e_game->getHpDamage();
            e_game->removedEnemy(this);
            return;
        }
    }

    // 在前往航点的路上
    // 目标航点的坐标
    QPoint targetPoint = e_Point->pos();
    // 未来修改这个可以添加移动状态,加快,减慢,m_walkingSpeed是基准值

    // 向量标准化
    qreal movementSpeed = e_walkingSpeed;
    QVector2D normalized(targetPoint - e_pos);//向量，从现在的点指向下一个路线点
    normalized.normalize(); //normalized取值只有(1,0),(-1,0),(0,-1),(0,1)四种
    e_pos = e_pos + normalized.toPoint() * movementSpeed;

    // 确定敌人选择方向
    // 默认图片向左,需要修正180度转右
    e_rotationSprite = qRadiansToDegrees(qAtan2(normalized.y(), normalized.x())) + 180;
}

void Enemy::d(QPainter *painter) const
{
    if (!e_active)
        return;

    painter->save();

    // 绘制血条
    QPoint healthBarPoint = e_pos + QPoint(-25, -ms_fixedSize.height() / 3);//血条长条的左上角
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarBackRect(healthBarPoint, QSize(e_maxHp, 4));//先画一条红色的，固定长度
    painter->drawRect(healthBarBackRect);

    painter->setBrush(Qt::green);//根据剩余血量画一条绿色的 ，视觉上形成被攻击时绿色血条减少，露出红色血条
    QRect healthBarRect(healthBarPoint, QSize(e_currentHp, 4));
    painter->drawRect(healthBarRect);

    // 绘制敌人
    static const QPoint offsetPoint(-ms_fixedSize.width() / 2, -ms_fixedSize.height() / 2);// 绘制偏转坐标,由中心+偏移=左上
    painter->translate(e_pos);//以路线点为中心
    painter->rotate(e_rotationSprite);// 偏转
    painter->drawPixmap(offsetPoint, e_sprite);

    painter->restore();
}

void Enemy::Removed()
{
    if (e_attackedTowersList.empty())
        return;

    foreach (Tower *attacker, e_attackedTowersList)
         attacker-> t_targetKilled();
    // 通知game,此敌人已经阵亡
    e_game->removedEnemy(this);
}

void Enemy::Damage(int damage)
{

    e_currentHp -= damage;

    // 阵亡,需要移除
    if (e_currentHp <= 0)
    {
        e_game->awardGold(200);
        Removed();
    }
}

 //受到攻击，将攻击的这个塔存入列表
void Enemy::Attacked(Tower *attacker)
{
    e_attackedTowersList.push_back(attacker);
}

// 敌人已经逃离攻击范围
void Enemy::LostSight(Tower *attacker)
{

    e_attackedTowersList.removeOne(attacker);
}

QPoint Enemy::pos() const
{

    return e_pos;
}
