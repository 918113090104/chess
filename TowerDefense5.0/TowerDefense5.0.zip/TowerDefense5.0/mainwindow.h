#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include "tower.h"
#include "towerposition.h"

namespace Ui {
class MainWindow;
}

class WayPoint;
class Enemy;
class Bullet;
class AudioPlayer;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);//
    ~MainWindow();//

    void getHpDamage(int damage = 1);
    void removedEnemy(Enemy *enemy);//消灭敌人则进行移除操作
    void removedBullet(Bullet *bullet);//移除子弹
    void addBullet(Bullet *bullet);
    void awardGold(int gold);//消灭一个敌人奖励相应金币

    AudioPlayer* audioPlayer() const;
    QList<Enemy *> enemyList() const;

protected:
    void paintEvent(QPaintEvent *);//所有绘制
    void mousePressEvent(QMouseEvent *);//鼠标点击放置塔

private slots:
    void updateMap();
    void gameStart();

private:
    void main_loadTowerPositions(); //获取基地的位置,将基地位置存入towerPositionsList列表
    void  main_addWayPoints();//获取路线点的位置，存入wayPointsList列表
    bool  main_loadWave();//将获得的波数信息存入enemyList列表
    bool  main_canBuyTower() const; //
    void  main_drawWave(QPainter *painter);
    void  main_drawHP(QPainter *painter);
    void  main_drawPlayerGold(QPainter *painter);
    void  main_doGameOver();
    void  main_preLoadWavesInfo();//获取攻击波数信息

private:
    Ui::MainWindow *		ui;
    int						 main_waves;//当前攻击的波数
    int						 main_playerHp;
    int						 main_playrGold; //玩家的金币数，初始为1000
    bool					 main_gameEnded;
    bool					 main_gameWin;
    AudioPlayer *			 main_audioPlayer;
    QList<QVariant>			 main_wavesInfo; //
    QList<TowerPosition>	 main_towerPositionsList; //数组列表，存储塔的位置
    QList<Tower *>			 main_towersList; //数组列表，塔
    QList<WayPoint *>		 main_wayPointsList; //数组列表，路线点
    QList<Enemy *>			 main_enemyList; //数组列表，敌人
    QList<Bullet *>			 main_bulletList;//数组列表，子弹
};

#endif
