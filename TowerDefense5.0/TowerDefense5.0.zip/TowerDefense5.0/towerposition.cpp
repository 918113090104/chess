#include "towerposition.h"
#include <QPainter>

const QSize TowerPosition::tp_fixedSize(73, 73);

TowerPosition::TowerPosition(QPoint pos, const QPixmap &sprite/* = QPixmap(":/image/open_spot.png")*/)
    : tp_hasTower(false)
    , tp_pos(pos)
    , tp_sprite(sprite)
{
}
const QPoint TowerPosition::centerPos() const
{
    QPoint offsetPoint(tp_fixedSize.width() / 2, tp_fixedSize.height() / 2);
    return tp_pos + offsetPoint;
}

bool TowerPosition::containPoint(const QPoint &pos) const
{
    //判断鼠标点击的位置是否在基地范围之内
    bool isXInHere = tp_pos.x() < pos.x() && pos.x() < (tp_pos.x() + tp_fixedSize.width());
    bool isYInHere = tp_pos.y() < pos.y() && pos.y() < (tp_pos.y() + tp_fixedSize.height());
	return isXInHere && isYInHere;
}
bool TowerPosition::Tower() const
{
    return tp_hasTower;
}

void TowerPosition::HOST(bool hasTower/* = true*/)
{
    tp_hasTower = hasTower;
}

void TowerPosition::draw(QPainter *painter) const
{
    //绘制基地
    painter->drawPixmap(tp_pos.x(), tp_pos.y(), tp_sprite);
}

