#include "mainwindow.h"
#include <QApplication>
#include<dialog.h>

int main(int argc, char *argv[])
{


    QApplication a(argc, argv);
    MainWindow w;


    Dialog d;//创建对话框。
    if(d.exec() == QDialog::Accepted){//当按钮“进入主界面”被按下则执行
       w.show();
       return a.exec();
    }
    return 0;//否则退出程序
}
