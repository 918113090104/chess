#ifndef PLISTREADER_H
#define PLISTREADER_H

#include <QXmlStreamReader>

class PListReader
{
public:
    PListReader();

    bool P_read(QIODevice *device);
    const QList<QVariant> data() const;

    QString  P_errorString() const;

private:
    void  P_readPList();
    void  P_readPList1();
    void  P_readArray(QList<QVariant> &array);//
    void  P_readDict(QList<QVariant> &array);
    void  P_readDct(QList<QVariant> &array);
    void  P_readKey(QMap<QString, QVariant> &dict);

private:
    QXmlStreamReader	m_xmlReader;
    QList<QVariant>		m_data;
};

#endif
