#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>

class WayPoint;
class QPainter;
class MainWindow;
class Tower;

class Enemy : public QObject
{
    Q_OBJECT
public:
    Enemy(WayPoint *startWayPoint, MainWindow *game, const QPixmap &sprite = QPixmap(":/image/enemy.png"));
    ~Enemy();//析构函数

    void d(QPainter *painter) const;//绘制
    void m();//敌人移动
    void Damage(int damage);//受到攻击自身血量减少，并判断是否身亡进行remove()操作
    void Removed();//将攻击对象从塔的列表中清除，通知game进行移除
    void Attacked(Tower *attacker);// 受到攻击，将攻击的这个塔存入列表
    void LostSight(Tower *attacker);//
    QPoint pos() const;

public slots:
    void doActivate();

private://定义相关的变量
    bool			e_active;//敌人状态，是否产生
    int				e_maxHp;//最大血量值
    int				e_currentHp;//当前血量值
    qreal			e_walkingSpeed;//敌人移动的速度
    qreal			e_rotationSprite;//图片偏转的度数

    QPoint			e_pos;//当前位置的坐标
    WayPoint *		e_Point;//移动的下一个路线点的坐标
    MainWindow *	e_game;//
    QList<Tower *>	e_attackedTowersList;//

    const QPixmap	e_sprite;//敌人图片
    static const QSize ms_fixedSize;//图片大小
};

#endif
