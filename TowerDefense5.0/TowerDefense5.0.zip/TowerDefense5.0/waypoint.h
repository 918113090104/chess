#ifndef WAYPOINT_H
#define WAYPOINT_H

#include <QPoint>

class QPainter;

// 移动的航线
class WayPoint
{
public:

    const QPoint pos() const;
    WayPoint(QPoint pos);
    WayPoint* nextWayPoint() const;
    void draw(QPainter *painter) const;//绘制
    void setNextWayPoint(WayPoint *nextPoint);//下一个点

private:
    const QPoint		m_pos;//当前点坐标
    int BB;
    WayPoint *			w_Point;//下一个点

};

#endif
