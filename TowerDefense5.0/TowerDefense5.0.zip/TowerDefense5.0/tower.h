#ifndef TOWER_H
#define TOWER_H

#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QObject>

class QPainter;
class Enemy;
class MainWindow;
class QTimer;

class Tower : QObject
{
    Q_OBJECT
public:
    Tower(QPoint pos,//头
    MainWindow *game,//yx
    const QPixmap &sprite = QPixmap(":/image/t.png"));//获取敌人图片
    ~Tower();//析构函数
    void t_chooseEnemyForAttack(Enemy *enemy); //
    void  t_targetKilled();//
    void  t_attackEnemy(); //
    void  t_draw(QPainter *painter) const;//
    void  t_checkEnemyInRange();//
    void  t_lostSightOfEnemy();//

private slots:
    void shootWeapon();

private:
    bool			m_attacking;
    int				m_damage;		// 攻击敌人造成的伤害
    int				m_fireRate;		//  攻击敌人时间间隔
    int				m_attackRange;	//  塔攻击敌人的距离
    qreal			m_rotationSprite;//炮台偏转的度数

    Enemy *			m_chooseEnemy;//
    MainWindow *	m_game;//
    QTimer *		m_fireRateTimer;
    const QPoint	m_pos;//点击的位置对应基地的中心坐标
    const QPixmap	m_sprite;//塔的图片
    static const QSize ms_fixedSize;//塔的大小
};

#endif
